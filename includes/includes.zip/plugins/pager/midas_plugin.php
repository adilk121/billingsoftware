<?
require(dirname(__FILE__)."/pager.class.php") ;
require(dirname(__FILE__)."/pager_sql.class.php") ;